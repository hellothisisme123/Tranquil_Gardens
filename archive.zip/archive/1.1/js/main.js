var rand = parseInt(Math.random() * 2)
console.log(rand)