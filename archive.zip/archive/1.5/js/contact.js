const left = document.querySelector('.contact_type.left'),
      middle = document.querySelector('.contact_type.middle'),
      right = document.querySelector('.contact_type.right'),
      transitional = document.querySelector('.transitional'),
      container = document.querySelector('.container')
      

left.addEventListener('click', (e) => {
    console.log(left)
    transitional.style.transition = 'left 1s cubic-bezier(0.075, 0.82, 0.165, 1)'
    transitional.style.left = '0'
    
    
    
    
    
    // middle.style.clipPath = 'polygon(0 0, 0 0, 0 0, 0 0)'
    // right.style.clipPath = 'polygon(100% 0, 100% 0, 100% 100%, 100% 100%)'
    // left.style.clipPath = 'polygon(0 0, 100% 0, 100% 100%, 0 100%)'
    // setTimeout(() => {
        // left.remove()
        // middle.remove()
        // right.remove()
        // container.style.backgroundColor = 'var(--color_1)'
        // left.style.width = '100vw'
        // left.style.gridColumn = 'span 3'
    // }, 1000);
})

middle.addEventListener('click', (e) => {
    console.log(left)
    transitional.style.backgroundColor = 'var(--color_2)'
    transitional.style.transition = 'left 1s cubic-bezier(0.075, 0.82, 0.165, 1)'
    transitional.style.left = '0'
})

right.addEventListener('click', (e) => {
    console.log(left)
    transitional.style.transition = 'left 1s cubic-bezier(0.075, 0.82, 0.165, 1)'
    transitional.style.left = '0'
})